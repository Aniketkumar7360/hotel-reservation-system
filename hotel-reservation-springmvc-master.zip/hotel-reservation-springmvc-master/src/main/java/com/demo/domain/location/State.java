package com.demo.domain.location;

public enum State {
    SA, WA, NT, TAS, NSW, VIC, ACT, QLD;
}
