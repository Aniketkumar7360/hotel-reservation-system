package com.demo.reservation.testcheckboxes;

public enum EnumDrink {
    Coke, Fanta, Sprite
}
