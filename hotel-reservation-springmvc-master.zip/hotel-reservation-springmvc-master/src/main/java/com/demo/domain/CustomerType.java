package com.demo.domain;

public enum CustomerType {
    Regular, Corporate
}
